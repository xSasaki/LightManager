const { ActivityType } = require("discord.js")
require('colors')
const { exec } = require('child_process');
const ms = require("ms")
getNow = () => { return { time: new Date().toLocaleString("fr-FR", { timeZone: "Europe/Paris", hour12: false, hour: "2-digit", minute: "2-digit", second: "2-digit" }), }; };

module.exports = async (client, Bot, Client, bot, send) => {

  console.log("Bot".blue + " >>" + ` Connecté sur ${client.user.username} (${client.user.id})`.green)
  client.user.setPresence({ activities: [{ name: client.config.status, type: ActivityType.Streaming, url: "https://twitch.tv/shinra" }] })
  console.log("Commandes".blue + " >> " + `${client.commands.size}`.red + ` Chargés`.green)
}